#pragma once

void dialogs_show_pixbuf (GtkWindow *parent, GdkPixbuf *pixbuf); 
void dialogs_show_text (GtkWindow *parent, const char *text);

